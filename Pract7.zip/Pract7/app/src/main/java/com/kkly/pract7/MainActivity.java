package com.kkly.pract7;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.kkly.pract7.dataadapter.TaskAdapter;
import com.kkly.pract7.datamanager.TaskDataManager;
import com.kkly.pract7.datamodels.Task;
import com.kkly.pract7.helpers.DatabaseHelper;

public class MainActivity extends AppCompatActivity {
    FloatingActionButton buttonAdd;
    GridView gridViewTasks;

    static int TASK_REQUEST_CODE = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DatabaseHelper.initialize(getApplicationContext());

        buttonAdd = findViewById(R.id.buttonAdd);
        gridViewTasks = findViewById(R.id.gridViewTasks);

        final TaskDataManager tdm = new TaskDataManager();
        Task[] tasks = tdm.getAllTasks();

        TaskAdapter adapter = new TaskAdapter(this, tasks);
        gridViewTasks.setAdapter(adapter);

        gridViewTasks.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final Task task = (Task) gridViewTasks.getItemAtPosition(position);

                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("What do you want to do?")
                        .setItems(new String[]{"Edit Task", "Complete Task"}, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if(which == 0){
                                    //Launch an intent to the edit activity for editing

                                    Intent i = new Intent(MainActivity.this, EditActivity.class);
                                    i.putExtra("id", task.getId());
                                    startActivityForResult(i, TASK_REQUEST_CODE);
                                }else{
                                    // complete the task

                                    new AlertDialog.Builder(MainActivity.this)
                                            .setMessage("Complete and remove task?")
                                            .setNegativeButton("No", null)
                                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                    task.setStatus("COMPLETE");
                                                    tdm.updateTask(task);
                                                    refreshList();
                                                }
                                            }).show();
                                }
                            }
                        }).show();

            }
        });


        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, EditActivity.class);
                intent.putExtra("id", "0");
                startActivityForResult(intent, TASK_REQUEST_CODE);

            }
        });
    }

    public void refreshList() {
        TaskDataManager tdm = new TaskDataManager();
        Task[] tasks = tdm.getAllTasks();

        TaskAdapter adapter = new TaskAdapter(this, tasks);
        gridViewTasks.setAdapter(adapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == TASK_REQUEST_CODE)
            refreshList();
    }
}