package com.kkly.pract7;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.kkly.pract7.datamanager.TaskDataManager;
import com.kkly.pract7.datamodels.Task;
import com.kkly.pract7.helpers.DateHelper;

import java.text.SimpleDateFormat;
import java.util.Date;

public class EditActivity extends AppCompatActivity {

    public static int OK_RESULT_CODE = 1;


    Button buttonSave;
    TextView textViewDateDue;
    EditText editTextDescription;
    RadioButton radioButtonGreen;
    RadioButton radioButtonBlue;
    RadioButton radioButtonRed;
    TaskDataManager tdm;

    Task task = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        tdm = new TaskDataManager();
        buttonSave = findViewById(R.id.buttonSave);
        textViewDateDue = findViewById(R.id.textViewDateDue);
        editTextDescription = findViewById(R.id.editTextDescription);
        radioButtonBlue = findViewById(R.id.radioButtonBlue);
        radioButtonGreen = findViewById(R.id.radioButtonGreen);
        radioButtonRed = findViewById(R.id.radioButtonRed);

        Intent intent = getIntent();
        int id = intent.getIntExtra("id",0);

        if(id == 0){
            //adding
            task = new Task(0, "", "G", "ACTIVE", DateHelper.convertTodayToDate());
        }else{
            //editing
            task = tdm.getTaskById(id);
        }

        final SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
        textViewDateDue.setText(dateFormat.format(task.getDateDue()));

        textViewDateDue.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Date dateDue = task.getDateDue();
                DateHelper currentDateDue = DateHelper.convertDateToYearMonthDay(dateDue);

                DatePickerDialog datePickerDialog = new DatePickerDialog(EditActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {

                        // year, month, day parameters store the date selected by the user!
                        //
                        Date newDateDue = DateHelper.convertYearMonthDayToDate(year, month, day);
                        task.setDateDue(newDateDue);

                        textViewDateDue.setText(dateFormat.format(task.getDateDue()));
                    }
                }, currentDateDue.year, currentDateDue.month, currentDateDue.day);

                // Remember to show the date picker dialog after creating it.
                //
                datePickerDialog.show();
            }
        });

        if(task.getColour().equals("G"))
            radioButtonGreen.setChecked(true);
        if(task.getColour().equals("B"))
            radioButtonBlue.setChecked(true);
        if(task.getColour().equals("R"))
            radioButtonRed.setChecked(true);

        editTextDescription.setText(task.getDescription());

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editTextDescription.getText().toString().equals("")){
                    editTextDescription.setError("Please enter a description");
                    return;
                }

                task.setDescription(editTextDescription.getText().toString());

                if(radioButtonBlue.isChecked())
                    task.setColour("B");
                if(radioButtonGreen.isChecked())
                    task.setColour("G");
                if(radioButtonRed.isChecked())
                    task.setColour("R");

                if(task.getId()==0){
                    //adding
                    tdm.addTask(task);
                    Toast.makeText(EditActivity.this, "New Task Added", Toast.LENGTH_SHORT).show();
                }else{
                    tdm.updateTask(task);
                    Toast.makeText(EditActivity.this, "Task Updated", Toast.LENGTH_SHORT).show();
                }

                setResult(OK_RESULT_CODE);
                finish();
            }
        });
    }
}