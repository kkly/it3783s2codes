package com.kkly.prac9;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class DataDownloader {
    ArrayList<TwitterStatus> statusList = new ArrayList<TwitterStatus>();

    // This method will perform the download
    //
    public ArrayList<TwitterStatus> startDownload() {
        try {
            String json = "";
            URL url = new
                    URL("https://drive.google.com/uc?export=download&id=1ruTLd0veLG4ZbiYz4__utZRvIeeG10cJ");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true);
            conn.connect();
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                InputStream inputStream = conn.getInputStream();
                BufferedReader buffer = new BufferedReader(new
                        InputStreamReader(inputStream));
                String s = "";
                // By this point in time, we will already have successfully opened
                // the connection
                // to the URL. What is left is to download the data from the server,
                //and we will
                // use the buffer to read the text line by line from the server, and
                //append it to
                // the 'json' variable.
                //
                while ((s = buffer.readLine()) != null) {
                    json += s;
                }
                try {
                    // In this block we will convert the 'json' variable (which
                    // contains our
                    // rseult string of json text downloaded from the server) into a
                    // JSONObject.
                    //
                    JSONObject jsonObject = new JSONObject(json);
                    // Since our statuses are stored in the "statuses" field in the
                    //JSON data.
                    // We can access it using jsonObject.getJSONArray("statuses")
                    //
                    JSONArray jsonArray = jsonObject.getJSONArray("statuses");
                    for (int i = 0, length = jsonArray.length(); i < length; i++) {
                        // Here we extract the i-th Twitter status posting.
                        //
                        JSONObject attribute = jsonArray.getJSONObject(i);
                        // And then we extract the status text, posting date/time.
                        //
                        String status = attribute.getString("text");
                        String postedDateTime = attribute.getString("created_at");
                        // Next we will retrieve the user's profile pic, which can
                        // be found inside the user attribute, in the property
                        //  called
                        // profile_background_image_url.
                        //
                        JSONObject userAttribute = attribute.getJSONObject("user");
                        String profilePic =
                                userAttribute.getString("profile_background_image_url");
                        // Once we have the 3 pieces of info: text, date/time,
                        // profile pic,
                        // let's create the TwitterStatus object.
                        //
                        TwitterStatus newStatus = new TwitterStatus(profilePic,
                                postedDateTime, status);
                        statusList.add(newStatus);
                    }
                } catch (Exception e) {
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return statusList;
    }
}
