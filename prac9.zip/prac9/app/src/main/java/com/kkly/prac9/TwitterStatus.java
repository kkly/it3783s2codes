package com.kkly.prac9;

public class TwitterStatus {

    String profilePic;
    String postedDateTime;
    String status;

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getPostedDateTime() {
        return postedDateTime;
    }

    public void setPostedDateTime(String postedDateTime) {
        this.postedDateTime = postedDateTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public TwitterStatus(String profilePic, String postedDateTime, String status) {
        this.profilePic = profilePic;
        this.postedDateTime = postedDateTime;
        this.status = status;
    }
}
