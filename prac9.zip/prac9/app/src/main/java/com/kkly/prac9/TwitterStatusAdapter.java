package com.kkly.prac9;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.InputStream;
import java.net.URL;

public class TwitterStatusAdapter  extends ArrayAdapter {
    private final Activity context;
    private final TwitterStatus[] data;

    public TwitterStatusAdapter(Activity context, TwitterStatus[] data){
        super(context, 0, data);
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View itemView = convertView;
        if(itemView == null){
            itemView = ((Activity)getContext()).getLayoutInflater().inflate(R.layout.listview_twitter, null, true);
        }

        TextView textViewDateTime = itemView.findViewById(R.id.textViewDateTime);
        TextView textViewStatus = itemView.findViewById(R.id.textViewStatus);
        ImageView imageView = itemView.findViewById(R.id.imageView);
        textViewDateTime.setText(data[position].getPostedDateTime());
        textViewStatus.setText(data[position].getStatus());


        new DownloadImageTask(imageView).execute(data[position].getProfilePic());


        return itemView;
    }


    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap>
    {
        ImageView imageViewToUpdate;
        public DownloadImageTask(ImageView imageView)
        {
            this.imageViewToUpdate = imageView;
        }
        // Remember this method executes code in the background thread.
        // But it cannot perform any updates to the UI.
        //
        @Override
        protected Bitmap doInBackground(String... urls) {
            String urlDisplay = urls[0];
            Bitmap bitmap = null;
            try
            {
                InputStream inputStream = new URL(urlDisplay).openStream();
                bitmap = BitmapFactory.decodeStream(inputStream);
            }
            catch (Exception e)
            {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return bitmap;
        }
        // This method is executed after doInBackground is complete and
        // this is where you can perform updates to the user interface.
        //
        @Override
        protected void onPostExecute(Bitmap bitmap) {
            imageViewToUpdate.setImageBitmap(bitmap);
        }
    }

}
