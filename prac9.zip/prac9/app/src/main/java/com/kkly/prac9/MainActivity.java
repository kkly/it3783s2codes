package com.kkly.prac9;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ProgressDialog progressDialog;
    Button buttonLoadData;
    ListView listViewData;
    ArrayList<TwitterStatus> statusList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        buttonLoadData = findViewById(R.id.buttonLoadData);
        listViewData = findViewById(R.id.listViewData);

        buttonLoadData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new GetTwitterStatusJsonTask().execute();
            }
        });


    }
    public class GetTwitterStatusJsonTask extends AsyncTask<Void, String, Boolean>
    {
        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(MainActivity.this, "Download",
                    "Fetching twitter data...", true);
        }
        @Override
        protected Boolean doInBackground(Void... voids) {
            try
            {
                // So here let's call our DataDownloader
                //
                DataDownloader downloader = new DataDownloader();
                statusList = downloader.startDownload();
            }
            catch (Exception ex)
            {
            }
            return true;
        }
        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            progressDialog.dismiss();
            if (statusList.size() > 0)
            {
                TwitterStatus[] statusArray = new TwitterStatus[0];
                TwitterStatusAdapter adapter = new
                        TwitterStatusAdapter(MainActivity.this, statusList.toArray(statusArray));
                listViewData.setAdapter(adapter);
            }
            else
            {
                Toast.makeText(MainActivity.this, "Twitter data is currently unavailable.", Toast.LENGTH_LONG).show();
            }
        }
    }
}