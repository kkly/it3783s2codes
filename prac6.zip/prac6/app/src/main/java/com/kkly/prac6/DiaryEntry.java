package com.kkly.prac6;

import java.util.Calendar;
import java.util.Date;

public class DiaryEntry {

    private String emotion;
    private String message;
    private String photoPath;
    private Date dateCreated;

    public DiaryEntry(String emotion, String message, String photoPath) {
        this.emotion = emotion;
        this.message = message;
        this.photoPath = photoPath;
       // this.dateCreated = dateCreated;
    }

    public String getEmotion() {
        return emotion;
    }

    public String getMessage() {
        return message;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public Date getDateCreated() {
        return Calendar.getInstance().getTime();
    }
}
