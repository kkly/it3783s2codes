package com.kkly.prac6;

import java.util.ArrayList;

public class DiaryEntryDataManager {

    ArrayList<DiaryEntry> diaryEntries;

    public DiaryEntryDataManager(){
        diaryEntries = new ArrayList<DiaryEntry>();
    }

    public DiaryEntry[] getAllDiaryEntries(){
        return diaryEntries.toArray(new DiaryEntry[0]);
    }

    public void addDiaryEntry(DiaryEntry diaryEntry){
        this.diaryEntries.add(diaryEntry);

    }

}
