package com.kkly.prac6;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class DiaryEntryNew extends AppCompatActivity {

    String[] emotions = {
            "Happy", "Excited", "Neutral", "Can Be Better" };

    Spinner spinnerEmotion;
    EditText editTextMessage;
    ImageView imageViewPhoto;
    Button buttonTakePhoto;
    Button buttonAdd;

    String photoPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary_entry_new);
        spinnerEmotion = findViewById(R.id.spinnerEmotion);
        editTextMessage = findViewById(R.id.editTextMessage);
        imageViewPhoto = findViewById(R.id.imageViewDiaryEntryImage);
        buttonAdd = findViewById(R.id.buttonAdd2);
        buttonTakePhoto = findViewById(R.id.buttonTakePhoto);

        photoPath = "";

        ArrayAdapter<String> emotionAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, emotions);
        spinnerEmotion.setAdapter(emotionAdapter);

        buttonTakePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                photoPath = CameraHelper.dispatchTakePictureIntent(
                        DiaryEntryNew.this);
            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedEmotionPosition =
                        spinnerEmotion.getSelectedItemPosition();
                String emotion = emotions[selectedEmotionPosition];

                String message = editTextMessage.getText().toString();
                if (message.equals("")) {
                    editTextMessage.setError("Please enter your message");
                    Toast.makeText(DiaryEntryNew.this,
                            "Please enter your message",
                            Toast.LENGTH_SHORT).show();
                    return;
                }


                if (photoPath.equals("")) {
                    buttonTakePhoto.setError("Please take a photo");
                    Toast.makeText(DiaryEntryNew.this, "Please take a photo",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                DiaryEntry newDiaryEntry = new DiaryEntry(emotion, message, photoPath);
                MainActivity.diaryEntryDataManager
                        .addDiaryEntry(newDiaryEntry);

                DiaryEntryNew.this.finish();
            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == CameraHelper.REQUEST_TAKE_PHOTO){
            if(resultCode == RESULT_OK){
                CameraHelper.showPictureOnImageView(this, photoPath, imageViewPhoto);
            }
        }
    }
}