package com.kkly.prac6;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    public static DiaryEntryDataManager diaryEntryDataManager;
    FloatingActionButton buttonAdd;
    ListView listViewDiaryEntries;

    int REQUEST_NEW_DIARY_ENTRY = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listViewDiaryEntries = findViewById(R.id.listViewDiaryEntries);
        buttonAdd = findViewById(R.id.buttonAdd);

        diaryEntryDataManager = new DiaryEntryDataManager();
        DiaryEntryAdapter adapter = new DiaryEntryAdapter(this, diaryEntryDataManager.getAllDiaryEntries());

        listViewDiaryEntries.setAdapter(adapter);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, DiaryEntryNew.class);
                startActivityForResult(intent, REQUEST_NEW_DIARY_ENTRY);

            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_NEW_DIARY_ENTRY) {
            refreshList();

        }
    }

    private void refreshList(){
            DiaryEntryAdapter adapter = new DiaryEntryAdapter(this, diaryEntryDataManager.getAllDiaryEntries());
            listViewDiaryEntries.setAdapter(adapter);

    }
}