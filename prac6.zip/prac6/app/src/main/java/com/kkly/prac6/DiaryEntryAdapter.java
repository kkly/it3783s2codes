package com.kkly.prac6;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;

//ArrayAdapter is override getView
public class DiaryEntryAdapter extends ArrayAdapter {
    DiaryEntry[] data1;

    public DiaryEntryAdapter(Context context, DiaryEntry[] data) {

        super(context, 0, data);
        this.data1 = data;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View itemView = convertView;

        if (itemView == null) {
            itemView = ((Activity) getContext())
                    .getLayoutInflater().inflate(R.layout.listview_post, null);
        }

        TextView textViewEmotion = itemView.findViewById(R.id.textViewEmotion);
        TextView textViewMessage = itemView.findViewById(R.id.textViewMessage);
        TextView textViewDateTime = itemView.findViewById(R.id.textViewDateTime);
        ImageView imageViewPhoto =
                itemView.findViewById(R.id.imageViewPhoto);

        textViewEmotion.setText(data1[position].getEmotion());
        textViewMessage.setText(data1[position].getMessage());

        SimpleDateFormat dateFormat =
                new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
        String output =
                dateFormat.format(data1[position].getDateCreated());

        textViewDateTime.setText(output);

        CameraHelper.showPictureOnImageView(
                (Activity)getContext(),
                data1[position].getPhotoPath(), imageViewPhoto);

        return itemView;

    }
}
