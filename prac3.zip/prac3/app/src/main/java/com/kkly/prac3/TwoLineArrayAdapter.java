package com.kkly.prac3;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class TwoLineArrayAdapter extends ArrayAdapter {

    String [][] data;

    public TwoLineArrayAdapter(Context context, String[][] data)
    {
        super(context, android.R.layout.simple_list_item_1,
                android.R.id.text1, data);
        this.data = data;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View itemView = convertView;
        if (itemView == null)
            itemView = ((Activity)this.getContext())
                    .getLayoutInflater().
                            inflate(android.R.layout.simple_list_item_2, null);

        TextView text1 = itemView.findViewById(android.R.id.text1);
        text1.setText(data[position][0]);
        TextView text2 = itemView.findViewById(android.R.id.text2);
        text2.setText(data[position][1]);
        return itemView;

    }


    public View getDropDownView(int position, View convertView, ViewGroup
            parent)
    {
        return getView(position, convertView, parent);
    }

}
