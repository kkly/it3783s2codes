package com.kkly.prac3;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class TitleDescriptionImageAdapter extends ArrayAdapter {
    private TitleDescriptionImage[] data;

    public TitleDescriptionImageAdapter(Context context,
                                        TitleDescriptionImage[] data)
    {
        super(context, 0, data);
        this.data = data;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View itemView = convertView;

        if (itemView == null)
            itemView = ((Activity)this.getContext()).getLayoutInflater()
                    .inflate(R.layout.list_title_description_image, null);

        TextView textTitle =
                itemView.findViewById(R.id.textViewTitle);
        textTitle.setText(data[position].getTitle());
        TextView textDescription =
                itemView.findViewById(R.id.textViewDescription);
        textDescription.setText(data[position].getDescription());
        ImageView imageView = itemView.findViewById(R.id.imageView);
        imageView.setImageResource(data[position].getImageResource());
        return itemView;



    }
}
