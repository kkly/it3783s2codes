package com.kkly.prac3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.lang.reflect.Array;

public class MainActivity extends AppCompatActivity {

    String[] countries = {"South Korea", "Taiwan"};
    String[][] placeTypes = {
            {"Nature",
                    "Parks, forests and everything untouched by people"},
            {"City",
                    "Urban life and majestic architectures"}
    };


    Spinner spinnerCountry;
    Spinner spinnerPlaceTypes;

    Button buttonSearch;
    ListView listViewPlaces;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerCountry = findViewById(R.id.spinnerCountry);
        spinnerPlaceTypes = findViewById(R.id.spinnerPlaceTypes);
        buttonSearch = findViewById(R.id.buttonSearch);
        listViewPlaces = findViewById(R.id.listViewPlaces);

        ArrayAdapter<String> countryAdapter =
                new ArrayAdapter<String>(this,
                        android.R.layout.simple_list_item_1,
                        countries);

        spinnerCountry.setAdapter(countryAdapter);


        TwoLineArrayAdapter placeTypesAdapter =
                new TwoLineArrayAdapter(this, placeTypes);
        spinnerPlaceTypes.setAdapter(placeTypesAdapter);


        buttonSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedCountryIndex =
                        spinnerCountry.getSelectedItemPosition();
                int selectedPlaceTypeIndex =
                        spinnerPlaceTypes.getSelectedItemPosition();
                TitleDescriptionImage[] places =
                        getPlaces(selectedCountryIndex, selectedPlaceTypeIndex);
                TitleDescriptionImageAdapter placesAdapter =
                        new TitleDescriptionImageAdapter(MainActivity.this, places);

                listViewPlaces.setAdapter(placesAdapter);

            }
        });

        listViewPlaces.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view,
                                            int position, long l) {
                        TitleDescriptionImage item =
                                (TitleDescriptionImage)listViewPlaces.getItemAtPosition(position);

                        Toast.makeText(MainActivity.this, "You selected: " + item.getTitle(),
                                Toast.LENGTH_LONG).show();

                    }
                });


    }

    protected TitleDescriptionImage[] getPlaces(int country, int
            placeType) {
        if (country == 0) {
            // South Korea
            if (placeType == 0) {
                // Nature
                return new TitleDescriptionImage[]
                        {
                                new TitleDescriptionImage("Pocheon Art Valley", "In what was Pocheon’s first environmental restoration project, the quarry was transformed into a beautiful park", R.drawable.sk_pocheon),
                                new TitleDescriptionImage("Seoraksan National Park", "An unspoiled landscape of sharp, rocky outcrops and windswept pine trees.", R.drawable.sk_seoraksan_national_park)
                        };
            } else {
                // City
                return new TitleDescriptionImage[]{
                        new TitleDescriptionImage("Bulguksa Temple", "Originally built in 528, it has endured a number of renovations and extensions throughout history", R.drawable.sk_bulguksa),
                        new TitleDescriptionImage("Jeonju Hanok Village", "The roads of Jeonju Hanok Village are lined with street-food vendors and restaurants carrying dishes that are traditional to Jeonju", R.drawable.sk_jeonju_hanok),
                        new TitleDescriptionImage("Gyeongbokgung", "Free guided tours are offered of this large, 14th-century royal palace", R.drawable.sk_gyeongbokgung),
                        new TitleDescriptionImage("N Seoul Tower", "Opened in 1980, this iconic tower offers panoramic views of the city & a revolving restaurant.", R.drawable.sk_seoul_tower),
                };
            }
        } else if (country == 1) {
            // Taiwan
            if (placeType == 0) {
                // Nature
                return new TitleDescriptionImage[]{
                        new TitleDescriptionImage("Taroko National Park", "Established in 1986, this 920-sq.-km. park features the Taroko Gorge, a memorial shrine & more.", R.drawable.tw_taroko),
                        new TitleDescriptionImage("Kenting National Park", "This area, Taiwan’s first national park, is an oceanfront destination with beaches & hiking trails.", R.drawable.tw_kenting),
                        new TitleDescriptionImage("Yangmingshan", "Scenic destination with hot springs & hiking trails.", R.drawable.tw_yangmingshan),
                };
            } else {
                // City
                return new TitleDescriptionImage[]{
                        new TitleDescriptionImage("Jiufen", "Jiufen is a mountain town in northeastern Taiwan, east of Taipei. ", R.drawable.tw_jiufen),
                        new TitleDescriptionImage("Taipei 101", "Towering, 106-floor modern skyscraper with light effects, shopping, dining & an observation deck.", R.drawable.tw_taipei_101),
                        new TitleDescriptionImage("Ximending", "Ximending is a neighborhood and shopping district in the Wanhua District of Taipei", R.drawable.tw_ximending),
                };

            }
        }
        return null;
    }


}