package com.kkly.prac7;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import com.kkly.prac7.datamanagers.TaskDataManager;
import com.kkly.prac7.datamodels.Task;
import com.kkly.prac7.helpers.DateHelper;

import java.text.SimpleDateFormat;
import java.util.Date;


public class EditActivity extends AppCompatActivity {

    public static int OK_RESULT_CODE = 1;

    Button buttonSave;
    TextView textViewDateDue;
    EditText editTextDescription;
    RadioButton radioButtonGreen;
    RadioButton radioButtonRed;
    RadioButton radioButtonBlue;

    Task task = null;


    protected void displayTask()
    {
        final SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");

        textViewDateDue = findViewById(R.id.textViewDateDue);
        textViewDateDue.setText(dateFormat.format(task.getDateDue()));
        textViewDateDue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            // We want to show a date picker dialog here
            //
            Date dateDue = task.getDateDue();
            DateHelper currentDateDue = DateHelper.convertDateToYearMonthDay(dateDue);

            DatePickerDialog datePickerDialog = new DatePickerDialog(EditActivity.this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker datePicker, int year, int month, int day) {

                    // year, month, day parameters store the date selected by the user!
                    //
                    Date newDateDue = DateHelper.convertYearMonthDayToDate(year, month, day);
                    task.setDateDue(newDateDue);

                    textViewDateDue.setText(dateFormat.format(task.getDateDue()));
                }
            }, currentDateDue.year, currentDateDue.month, currentDateDue.day);

            // Remember to show the date picker dialog after creating it.
            //
            datePickerDialog.show();

            }
        });

        radioButtonGreen = findViewById(R.id.radioButtonGreen);
        radioButtonBlue = findViewById(R.id.radioButtonBlue);
        radioButtonRed = findViewById(R.id.radioButtonRed);

        if (task.getColour().equals("G"))
            radioButtonGreen.setChecked(true);
        if (task.getColour().equals("B"))
            radioButtonBlue.setChecked(true);
        if (task.getColour().equals("R"))
            radioButtonRed.setChecked(true);

        editTextDescription = findViewById(R.id.editTextDescription);
        editTextDescription.setText(task.getDescription());
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        Intent intent = getIntent();
        String id = intent.getStringExtra("id");


        if (id.equals(""))
        {
            // Create a new empty task and then display its contents
            // in the user interface immediately.
            //
            task = new Task("", "", "G", "ACTIVE", DateHelper.convertTodayToDate());

            displayTask();
        }
        else
        {
            // Load the task details from Firebase. We will have to
            // display the user interface only after the download from the Firebase
            // is complete.
            //
            MainActivity.taskDataManager.getTaskById( id, new TaskDataManager.TaskValueListener() {
                @Override
                public void onValueReceived(Task taskFromFirebase) {
                    task = taskFromFirebase;
                    displayTask();
                }
            });
        }



        buttonSave = findViewById(R.id.buttonSave);
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // When the user clicks on the save button, let's perform
                // some validation first.
                //
                if (editTextDescription.getText().toString().equals(""))
                {
                    editTextDescription.setError("Please enter a description");
                    return;
                }

                // Then we retrieve all values from the UI widgets
                //
                task.setDescription(editTextDescription.getText().toString());

                if (radioButtonGreen.isChecked())
                    task.setColour("G");
                if (radioButtonBlue.isChecked())
                    task.setColour("B");
                if (radioButtonRed.isChecked())
                    task.setColour("R");

                // This segment here saves the task to the database
                //

                if (task.getId() == "")
                {
                    MainActivity.taskDataManager.addTask( task, new TaskDataManager.TaskUpdateCompleteListener() {
                        @Override
                        public void onUpdateComplete() {
                            Toast.makeText(EditActivity.this, "New task added", Toast.LENGTH_SHORT).show();

                            // Close off the activity.
                            setResult(OK_RESULT_CODE);
                            finish();
                        }
                    });
                }
                else
                {
                    MainActivity.taskDataManager.updateTask( task, new TaskDataManager.TaskUpdateCompleteListener() {
                        @Override
                        public void onUpdateComplete() {
                            Toast.makeText(EditActivity.this, "Task updated", Toast.LENGTH_SHORT).show();

                            // Close off the activity.
                            setResult(OK_RESULT_CODE);
                            finish();
                        }
                    });
                }

            }
        });
    }
}
