package com.kkly.prac7.datamanagers;




import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.kkly.prac7.datamodels.Task;

import java.util.ArrayList;

public class TaskDataManager {


    public interface TaskListListener
    {
        void onListReceived(Task[] tasks);
    }

    public interface TaskValueListener
    {
        void onValueReceived(Task task);
    }

    public interface TaskUpdateCompleteListener
    {
        void onUpdateComplete();
    }


    private DatabaseReference firebase;
// ...

    public TaskDataManager()
    {
        firebase = FirebaseDatabase.getInstance().getReference();
    }

    // This method gets a list of all tasks from the database, whose status are ACTIVE.
    // It will also order the tasks by the due date in descending order.
    //
    public void getAllTasks( final TaskListListener listener)
    {


        firebase.child("tasks")
            .orderByChild("status")
            .equalTo("ACTIVE")
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    ArrayList<Task> taskList = new ArrayList<>();

                    // Loop through each item downloaded from Firebase
                    // and create a Task for each item and add it into
                    // the taskList ArrayList.
                    //
                    for (DataSnapshot postSnapshot: dataSnapshot.getChildren()) {
                        String id = postSnapshot.getKey();
                        Task task = postSnapshot.getValue(Task.class);
                        task.setId(id);

                        taskList.add(task);
                    }

                    // After constructing our list of tasks, call our
                    // own TaskListListener's onListReceived method,
                    // so that our caller can update its UI.
                    //
                    if (listener != null) {
                        Task[] taskArray = new Task[0];
                        taskArray = taskList.toArray(taskArray);

                        listener.onListReceived(taskArray);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
    }


    // This method gets a single Task object given its ID.
    //
    public void getTaskById(String id, final TaskValueListener listener)
    {


        firebase.child("tasks")
            .child(id)            // Update using the existing ID.
            .addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Task task = dataSnapshot.getValue(Task.class);
                    task.setId(dataSnapshot.getKey());

                    if (listener != null)
                    {
                        listener.onValueReceived(task);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
    }


    // This method inserts a new Task into the Task table in our
    // SQLite database.
    //
    public void addTask(final Task task, final TaskUpdateCompleteListener listener)
    {


        firebase.child("tasks")
            .push()                 // automatically generates a new ID.
            .setValue(task, new DatabaseReference.CompletionListener() {
                @Override
                public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {

                    task.setId(databaseReference.getKey());

                    // Informs the caller that the update is complete.
                    if (listener != null)
                        listener.onUpdateComplete();

                }
            });
    }


    // This method inserts or replaces a new Task (with the same ID) into the Task table in our
    // SQLite database.
    //
    public void updateTask( final Task task, final TaskUpdateCompleteListener listener)
    {


        firebase.child("tasks")
            .child(task.getId())            // Update using the existing ID.
            .setValue(task, new DatabaseReference.CompletionListener() {
                @Override
                public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {

                    task.setId(databaseReference.getKey());

                    // Informs the caller that the update is complete.
                    if (listener != null)
                        listener.onUpdateComplete();

                }
            });
    }



}
