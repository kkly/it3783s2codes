package com.kkly.prac7;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.kkly.prac7.dataadapters.TaskAdapter;
import com.kkly.prac7.datamanagers.TaskDataManager;
import com.kkly.prac7.datamodels.Task;
import com.kkly.prac7.helpers.DatabaseHelper;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static TaskDataManager taskDataManager = new TaskDataManager();

    // UI widgets
    //
    FloatingActionButton buttonAdd;
    GridView gridViewTasks;

    static int TASK_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridViewTasks = findViewById(R.id.gridViewTasks);
        gridViewTasks.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int position, long l) {

                // When the taps on one of the items in the GridVIew, show a popup dialog
                // that allows user to select one of the following choices:
                //  Edit Task / Complete Task
                //
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("What do you want to do?")
                        .setItems(new String[]{"Edit Task", "Complete Task"}, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int itemSelected) {

                                final Task task = (Task) gridViewTasks.getItemAtPosition(position);

                                // TODO:
                                // Integrate with Firebase


                                if (itemSelected == 0) {
                                    // "Edit Task" was selected.
                                    //
                                    Intent intent = new Intent(MainActivity.this, EditActivity.class);
                                    intent.putExtra("id", task.getId());
                                    startActivityForResult(intent, TASK_REQUEST_CODE);
                                } else {
                                    // "Complete Task" was selected.
                                    // Let's show an alert to ask user for confirmation before removing
                                    // the task from view.
                                    //
                                    new AlertDialog.Builder(MainActivity.this)
                                            .setMessage("Complete and remove task?")
                                            .setNegativeButton("No", null)
                                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialogInterface, int i) {
                                                    task.setStatus("COMPLETE");
                                                    MainActivity.taskDataManager.updateTask(task, new TaskDataManager.TaskUpdateCompleteListener() {
                                                        @Override
                                                        public void onUpdateComplete() {
                                                            refreshList();
                                                        }
                                                    });
                                                }
                                            })
                                            .show();
                                }
                            }
                        })
                        .show();

            }
        });

        buttonAdd = findViewById(R.id.buttonAdd);
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // TODO:
                // Pass an empty String "id" into the EditActivity.

                // Show our EditActivity.
                //
                Intent intent = new Intent(MainActivity.this, EditActivity.class);
                intent.putExtra("id", "");
                startActivityForResult(intent, TASK_REQUEST_CODE);


            }
        });

        refreshList();

        // TODO:
        // Firebase Authentication.
    }

    // TODO:
    // Add methods for Firebase Authentication.

    public void refreshList() {
        // TODO:
        // Integrate with Firebase to load the full list of tasks
        // and display it in our GridView.


       taskDataManager.getAllTasks( new TaskDataManager.TaskListListener() {
           @Override
           public void onListReceived(Task[] tasks) {
           TaskAdapter adapter = new TaskAdapter(MainActivity.this, tasks);
           gridViewTasks.setAdapter(adapter);
           }
       });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == TASK_REQUEST_CODE) {
            refreshList();
        }

        // TODO:
        // Handle what happens after the Firebase Authentication completes.
        // (The authentication may be successful or may have failed)
    }
}
